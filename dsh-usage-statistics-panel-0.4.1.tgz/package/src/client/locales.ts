/**
 * Usage panel dictionaries, registered into the DSH locale service. The keys
 * mirror the reasonix stats locale block (settings.stats.*) plus the PR#7503
 * additions ("Other", 180-day trend note); values are the same Chinese and
 * English copy with the zh-TW variant transliterated.
 */

/** The locale namespace this plugin owns. */
export const LOCALE_NS = 'usageStats'

/** The typed translator key union for the panel's locale seat. */
export type UsageStatsKey =
  | 'nav'
  | 'back'
  | 'range'
  | 'rangePreset.7'
  | 'rangePreset.14'
  | 'rangePreset.30'
  | 'rangePreset.90'
  | 'rangeCustom'
  | 'from'
  | 'to'
  | 'refresh'
  | 'rebuild'
  | 'rebuildConfirm'
  | 'rebuilding'
  | 'rebuildHint'
  | 'loading'
  | 'tokens'
  | 'tokensHint'
  | 'cachedTokens'
  | 'sessions'
  | 'requests'
  | 'activeDays'
  | 'cacheRate'
  | 'cacheRateHint'
  | 'cacheHitRate'
  | 'hitRateLegend'
  | 'topModel'
  | 'topModelHint'
  | 'heatmap'
  | 'heatLess'
  | 'heatMore'
  | 'dailyTrend'
  | 'trendLimited'
  | 'modelUsage'
  | 'providerUsage'
  | 'providerModels'
  | 'other'
  | 'total'
  | 'percent'
  | 'asOf'
  | 'empty'
  | 'cachePrecision'
  | 'cachePrecisionDesc'
  | 'tokenDetail'
  | 'tokenDetailDesc'
  | 'streamThroughput'
  | 'streamThroughputDesc'
  | 'stats.counts'
  | 'stats.tokensPerSecond'
  | 'stats.cacheHit'
  | 'stats.cacheMiss'
  | 'stats.dialog.title'
  | 'stats.dialog.usageTitle'
  | 'stats.dialog.llmTime'
  | 'stats.dialog.toolTime'
  | 'stats.dialog.ttft'
  | 'stats.dialog.speed'
  | 'message.turnUsage.count'
  | 'message.turnUsage.cacheHit'
  | 'message.turnUsage.input'
  | 'message.turnUsage.cacheRead'
  | 'message.turnUsage.cacheWrite'
  | 'message.turnUsage.output'
  | 'costOverview'
  | 'costNote'
  | 'balance'
  | 'balanceBonus'
  | 'balanceTopUp'
  | 'balanceSignedOut'
  | 'balanceUnavailable'
  | 'balanceFailed'
  | 'balanceUpdated'
  | 'balanceRefresh'
  | 'balanceDaysLeftLess'
  | 'balanceDaysLeft'
  | 'periodToday'
  | 'period7d'
  | 'period30d'
  | 'periodAll'
  | 'priceTable'
  | 'priceHit'
  | 'priceMiss'
  | 'priceOutput'
  | 'pricePeakNote'
  | 'priceUnpriced'
  | 'sessionUsage'
  | 'sessionAvg'
  | 'sessionRescan'
  | 'sessionEmpty'
  | 'sessionTotal'
  | 'attribution'
  | 'attributionHint'
  | 'attributionRest'
  | 'attributionCoverage'
  | 'splitModel'
  | 'splitDay'
  | 'rowDetails'
  | 'metricTokens'
  | 'metricCost'
  | 'costEstimate'
  | 'colSession'
  | 'colTime'
  | 'colModels'

export const en: Record<UsageStatsKey, string> = {
  nav: 'Usage statistics',
  back: 'Back',
  range: 'Time range',
  'rangePreset.7': 'Last 7 days',
  'rangePreset.14': 'Last 14 days',
  'rangePreset.30': 'Last 30 days',
  'rangePreset.90': 'Last 90 days',
  rangeCustom: 'Custom',
  from: 'From',
  to: 'To',
  refresh: 'Refresh',
  rebuild: 'Rebuild',
  rebuildConfirm: 'Rebuild?',
  rebuilding: 'Rebuilding',
  rebuildHint: 'Rebuild the statistics from session logs: clear the local cache and replay every session. Use it when the figures look wrong.',
  loading: 'Loading',
  tokens: 'Token usage',
  tokensHint: 'Provider-visible total: uncached input + output + cached tokens',
  cachedTokens: 'cached',
  sessions: 'Sessions',
  requests: 'Requests',
  activeDays: 'Active days',
  cacheRate: 'Avg cache hit rate',
  cacheRateHint: 'Cached input tokens as a share of all input tokens in the range',
  cacheHitRate: 'Cache hit rate',
  hitRateLegend: 'Cache hit rate',
  topModel: 'Top model',
  topModelHint: 'Ranked by token volume, not call count',
  heatmap: 'Activity heatmap',
  heatLess: 'Less',
  heatMore: 'More',
  dailyTrend: 'Daily token trend',
  trendLimited: 'Showing the latest {n} days',
  modelUsage: 'Model usage',
  providerUsage: 'Provider usage',
  providerModels: '{n} models',
  other: 'Other',
  total: 'Total',
  percent: 'Share',
  asOf: 'As of',
  empty: 'No usage data in this time range yet. Token usage is recorded from the day the panel is installed, including a one-time scan of your existing sessions.',
  cachePrecision: 'Precise cache hit rate',
  cachePrecisionDesc: 'Show the cache hit rate with two decimals in the conversation bottom bar.',
  tokenDetail: 'Conversation token breakdown',
  tokenDetailDesc: 'Show total, cache hit/miss and output tokens in the conversation bottom bar.',
  streamThroughput: 'Streaming throughput',
  streamThroughputDesc: 'Show an estimated decode speed in the conversation bottom bar while a response streams, then the exact session figure once it settles.',
  'stats.counts': '{turns} turns · {steps} steps',
  'stats.tokensPerSecond': '{throughput} tok/s',
  'stats.cacheHit': 'Cache hit {percent}%',
  'stats.cacheMiss': 'Cache miss',
  'stats.dialog.title': 'Time & speed',
  'stats.dialog.usageTitle': 'Token usage',
  'stats.dialog.llmTime': 'LLM time',
  'stats.dialog.toolTime': 'Tool time',
  'stats.dialog.ttft': 'Mean TTFT',
  'stats.dialog.speed': 'Decode speed',
  'message.turnUsage.count': '{count} tok',
  'message.turnUsage.cacheHit': 'Cache hit',
  'message.turnUsage.input': 'Input',
  'message.turnUsage.cacheRead': 'Cache read',
  'message.turnUsage.cacheWrite': 'Cache write',
  'message.turnUsage.output': 'Output',
  costOverview: 'Cost & balance',
  costNote: 'Weighted estimate from the official peak / off-peak rates',
  balance: 'Account balance',
  balanceBonus: 'Bonus',
  balanceTopUp: 'Top up',
  balanceSignedOut: 'Not signed in to a DeepSeek account',
  balanceUnavailable: 'The account service is not mounted on this host',
  balanceFailed: 'Could not read the balance',
  balanceUpdated: 'Updated {time}',
  balanceRefresh: 'Refresh balance',
  balanceDaysLeftLess: 'Less than a day left',
  balanceDaysLeft: '~{n} days left',
  periodToday: 'Today',
  period7d: 'Last 7 days',
  period30d: 'Last 30 days',
  periodAll: 'All time',
  priceTable: 'Price per 1M tokens',
  priceHit: 'Cache hit',
  priceMiss: 'Cache miss',
  priceOutput: 'Output',
  pricePeakNote: 'Off-peak – peak; peak runs 09:00–12:00 and 14:00–18:00 on weekdays (Beijing time)',
  priceUnpriced: 'Unpriced, excluded: {models}',
  sessionUsage: 'Usage by conversation',
  sessionAvg: '{n} tokens per conversation on average',
  sessionRescan: 'Rescan',
  sessionEmpty: 'No sessions to measure yet',
  sessionTotal: '{n} sessions in total',
  attribution: 'Top spending conversations',
  attributionHint: 'Pick a period to see which conversations spent it',
  attributionRest: '{n} more conversations',
  attributionCoverage: 'Across {n} scanned conversations',
  splitModel: 'By model',
  splitDay: 'By day',
  rowDetails: 'Details',
  metricTokens: 'Tokens',
  metricCost: 'Cost',
  costEstimate: 'Est. {estimate}',
  colSession: 'Session',
  colTime: 'When',
  colModels: 'Models',
}

export const zh: Record<UsageStatsKey, string> = {
  nav: '使用统计',
  back: '返回',
  range: '时间范围',
  'rangePreset.7': '最近 7 天',
  'rangePreset.14': '最近 14 天',
  'rangePreset.30': '最近 30 天',
  'rangePreset.90': '最近 90 天',
  rangeCustom: '自定义',
  from: '开始日期',
  to: '结束日期',
  refresh: '刷新',
  rebuild: '重建统计',
  rebuildConfirm: '确认重建？',
  rebuilding: '重建中',
  rebuildHint: '按会话日志重建统计：清空本地统计缓存并重放全部会话。数字异常时使用。',
  loading: '加载中',
  tokens: 'Tokens 用量',
  tokensHint: '服务商总口径：未缓存输入 + 输出 + 缓存命中 token',
  cachedTokens: '缓存命中',
  sessions: '会话数量',
  requests: '请求数量',
  activeDays: '活跃天数',
  cacheRate: '平均缓存命中率',
  cacheRateHint: '时间段内缓存命中 token 占输入 token 的比例',
  cacheHitRate: '缓存命中率',
  hitRateLegend: '缓存命中率',
  topModel: '最常用模型',
  topModelHint: '按 token 用量排序，非调用次数',
  heatmap: '活跃热力图',
  heatLess: '较少',
  heatMore: '较多',
  dailyTrend: '按天 Token 趋势',
  trendLimited: '仅显示最近 {n} 天',
  modelUsage: '模型用量',
  providerUsage: '各供应商用量',
  providerModels: '{n} 个模型',
  other: '其他',
  total: '总用量',
  percent: '占比',
  asOf: '统计截至',
  empty: '当前时间范围内暂无用量数据。Token 用量从本面板启用后开始累计，并会一次性回扫已有的历史会话。',
  cachePrecision: '精确缓存命中率',
  cachePrecisionDesc: '在会话底部信息栏以两位小数显示缓存命中率。',
  tokenDetail: '会话 Token 明细',
  tokenDetailDesc: '在会话底部信息栏显示总 Token、命中/未命中缓存与输出明细。',
  streamThroughput: '流式吞吐速度',
  streamThroughputDesc: '输出过程中在会话底部信息栏显示估算的解码速度，输出结束后回到会话累计的精确值。',
  'stats.counts': '{turns} 轮 · {steps} 步',
  'stats.tokensPerSecond': '{throughput} tok/s',
  'stats.cacheHit': '缓存命中 {percent}%',
  'stats.cacheMiss': '未命中缓存',
  'stats.dialog.title': '用时与速度',
  'stats.dialog.usageTitle': 'Token 用量',
  'stats.dialog.llmTime': 'LLM 用时',
  'stats.dialog.toolTime': '工具用时',
  'stats.dialog.ttft': '首 token 平均',
  'stats.dialog.speed': '解码速度',
  'message.turnUsage.count': '{count} tok',
  'message.turnUsage.cacheHit': '缓存命中',
  'message.turnUsage.input': '输入',
  'message.turnUsage.cacheRead': '缓存读取',
  'message.turnUsage.cacheWrite': '缓存写入',
  'message.turnUsage.output': '输出',
  costOverview: '花费与余额',
  costNote: '按官方高峰/空闲时段价格加权估算',
  balance: '账户余额',
  balanceBonus: '赠送',
  balanceTopUp: '充值',
  balanceSignedOut: '未登录 DeepSeek 账户',
  balanceUnavailable: '当前宿主未挂载账户服务',
  balanceFailed: '余额读取失败',
  balanceUpdated: '更新于 {time}',
  balanceRefresh: '刷新余额',
  balanceDaysLeftLess: '不足 1 天',
  balanceDaysLeft: '约可用 {n} 天',
  periodToday: '今日',
  period7d: '近 7 天',
  period30d: '近 30 天',
  periodAll: '累计',
  priceTable: '每百万 tokens 单价',
  priceHit: '缓存命中',
  priceMiss: '缓存未命中',
  priceOutput: '输出',
  pricePeakNote: '空闲～高峰；高峰为工作日 09:00–12:00、14:00–18:00（北京时间）',
  priceUnpriced: '无价格、未计入：{models}',
  sessionUsage: '会话用量',
  sessionAvg: '平均每次 {n} tokens',
  sessionRescan: '重新扫描',
  sessionEmpty: '还没有可统计的会话',
  sessionTotal: '共 {n} 个会话',
  attribution: '会话花费排行',
  attributionHint: '点开任意时间段，看这笔钱花在哪些会话',
  attributionRest: '其余 {n} 个会话',
  attributionCoverage: '已扫描 {n} 个会话',
  splitModel: '按模型',
  splitDay: '按天',
  rowDetails: '明细',
  metricTokens: '用量',
  metricCost: '花费',
  costEstimate: '估算 {estimate}',
  colSession: '会话',
  colTime: '时间',
  colModels: '模型',
}

export const zhTW: Record<UsageStatsKey, string> = {
  nav: '使用統計',
  back: '返回',
  range: '時間範圍',
  'rangePreset.7': '最近 7 天',
  'rangePreset.14': '最近 14 天',
  'rangePreset.30': '最近 30 天',
  'rangePreset.90': '最近 90 天',
  rangeCustom: '自訂',
  from: '開始日期',
  to: '結束日期',
  refresh: '重新整理',
  rebuild: '重建統計',
  rebuildConfirm: '確認重建？',
  rebuilding: '重建中',
  rebuildHint: '依會話日誌重建統計：清空本機統計快取並重放全部會話。數字異常時使用。',
  loading: '載入中',
  tokens: 'Tokens 用量',
  tokensHint: '服務商總口徑：未快取輸入 + 輸出 + 快取命中 token',
  cachedTokens: '快取命中',
  sessions: '會話數量',
  requests: '請求數量',
  activeDays: '活躍天數',
  cacheRate: '平均快取命中率',
  cacheRateHint: '時間範圍內快取命中 token 佔輸入 token 的比例',
  cacheHitRate: '快取命中率',
  hitRateLegend: '快取命中率',
  topModel: '最常用模型',
  topModelHint: '依 token 用量排序，非呼叫次數',
  heatmap: '活躍熱力圖',
  heatLess: '較少',
  heatMore: '較多',
  dailyTrend: '每日 Token 趨勢',
  trendLimited: '僅顯示最近 {n} 天',
  modelUsage: '模型用量',
  providerUsage: '各供應商用量',
  providerModels: '{n} 個模型',
  other: '其他',
  total: '總用量',
  percent: '佔比',
  asOf: '統計截至',
  empty: '目前時間範圍內尚無用量資料。Token 用量自本面板啟用後開始累計，並會一次掃描既有的歷史會話。',
  cachePrecision: '精確快取命中率',
  cachePrecisionDesc: '在會話底部資訊欄以兩位小數顯示快取命中率。',
  tokenDetail: '會話 Token 明細',
  tokenDetailDesc: '在會話底部資訊欄顯示總 Token、命中/未命中快取與輸出明細。',
  streamThroughput: '串流吞吐速度',
  streamThroughputDesc: '輸出過程中在會話底部資訊欄顯示估算的解碼速度，輸出結束後回到會話累計的精確值。',
  'stats.counts': '{turns} 輪 · {steps} 步',
  'stats.tokensPerSecond': '{throughput} tok/s',
  'stats.cacheHit': '快取命中 {percent}%',
  'stats.cacheMiss': '未命中快取',
  'stats.dialog.title': '用時與速度',
  'stats.dialog.usageTitle': 'Token 用量',
  'stats.dialog.llmTime': 'LLM 用時',
  'stats.dialog.toolTime': '工具用時',
  'stats.dialog.ttft': '首 token 平均',
  'stats.dialog.speed': '解碼速度',
  'message.turnUsage.count': '{count} tok',
  'message.turnUsage.cacheHit': '快取命中',
  'message.turnUsage.input': '輸入',
  'message.turnUsage.cacheRead': '快取讀取',
  'message.turnUsage.cacheWrite': '快取寫入',
  'message.turnUsage.output': '輸出',
  costOverview: '花費與餘額',
  costNote: '依官方尖峰／離峰時段價格加權估算',
  balance: '帳戶餘額',
  balanceBonus: '贈送',
  balanceTopUp: '儲值',
  balanceSignedOut: '未登入 DeepSeek 帳戶',
  balanceUnavailable: '目前宿主未掛載帳戶服務',
  balanceFailed: '餘額讀取失敗',
  balanceUpdated: '更新於 {time}',
  balanceRefresh: '重新整理餘額',
  balanceDaysLeftLess: '不足 1 天',
  balanceDaysLeft: '約可用 {n} 天',
  periodToday: '今日',
  period7d: '近 7 天',
  period30d: '近 30 天',
  periodAll: '累計',
  priceTable: '每百萬 tokens 單價',
  priceHit: '快取命中',
  priceMiss: '快取未命中',
  priceOutput: '輸出',
  pricePeakNote: '離峰～尖峰；尖峰為工作日 09:00–12:00、14:00–18:00（北京時間）',
  priceUnpriced: '無價格、未計入：{models}',
  sessionUsage: '工作階段用量',
  sessionAvg: '平均每次 {n} tokens',
  sessionRescan: '重新掃描',
  sessionEmpty: '尚無可統計的工作階段',
  sessionTotal: '共 {n} 個工作階段',
  attribution: '工作階段花費排行',
  attributionHint: '點開任一時段，看這筆錢花在哪些工作階段',
  attributionRest: '其餘 {n} 個工作階段',
  attributionCoverage: '已掃描 {n} 個工作階段',
  splitModel: '依模型',
  splitDay: '依天',
  rowDetails: '明細',
  metricTokens: '用量',
  metricCost: '花費',
  costEstimate: '估算 {estimate}',
  colSession: '工作階段',
  colTime: '時間',
  colModels: '模型',
}
