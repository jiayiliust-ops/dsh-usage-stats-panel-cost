/**
 * Account balance: the "how much money is left" half of the cost view.
 *
 * DeepSeek Harness signs in to the DeepSeek **platform** account (provider
 * `deepseek-account`), so the balance is the platform wallet, not the pay-as-
 * you-go API key balance. The host already owns that authenticated query:
 * `deepseekAccount.getBalance(client)` reads `GET /api/v0/users/get_user_summary`
 * with the stored grant and returns the recharge and bonus wallets. This
 * module wraps that service with a short cache (the panel refreshes on demand
 * and on range switches) and normalizes it into the wire shape.
 *
 * Everything degrades instead of throwing: a signed-out account, a host
 * without the account provider, and a failed platform call all produce a
 * snapshot the panel can render as a one-line state, never a dead section.
 */

import type { Context, UsageAccountClient, UsageAccountService } from './context-types.ts'
import type { BalanceSnapshot, BalanceWallet } from './wire.ts'

export interface BalanceOptions {
  /** How long a snapshot stays fresh (default 60 s). */
  cacheMs?: number
  /** Host version forwarded to the platform as `x-client-version`. */
  clientVersion?: string
  /** Extra client identity headers (locale is per request). */
  now?: () => number
}

/** Parse one platform balance string into a number, or null when it is not
 *  a finite decimal (the platform's grammar allows an omitted integer part
 *  and a decimal exponent, so `Number` is the right parser). */
function parseAmount(value: unknown): number | null {
  if (typeof value !== 'string' && typeof value !== 'number') return null
  const n = typeof value === 'number' ? value : Number(value)
  return Number.isFinite(n) ? n : null
}

/** Normalize a wallet row; unknown currencies are kept (the panel prints the
 *  symbol when it knows it, the code otherwise). */
function walletOf(raw: { currency?: unknown; balance?: unknown }, kind: 'recharge' | 'bonus'): BalanceWallet | null {
  const balance = parseAmount(raw?.balance)
  if (balance === null) return null
  const currency = typeof raw.currency === 'string' && raw.currency !== '' ? raw.currency : 'CNY'
  return { currency, balance, kind }
}

/** Cached, normalized balance reader over the host account service. */
export class BalanceService {
  private cached: { at: number; snapshot: BalanceSnapshot } | null = null
  private inflight: Promise<BalanceSnapshot> | null = null
  private readonly cacheMs: number
  private readonly clientVersion: string
  private readonly now: () => number

  constructor(
    private readonly ctx: Context,
    options: BalanceOptions = {},
  ) {
    this.cacheMs = options.cacheMs ?? 60_000
    this.clientVersion = options.clientVersion ?? '0.1.0'
    this.now = options.now ?? (() => Date.now())
  }

  /** The platform links (top-up / official usage page), independent of the
   *  balance read so a failed query still sends the user somewhere useful. */
  async links(): Promise<{ topUpUrl?: string; usageUrl?: string }> {
    const account = this.account()
    if (account === undefined) return {}
    try {
      const state = await account.getState?.()
      return state?.links ?? {}
    } catch {
      return {}
    }
  }

  /**
   * Read the current balance.
   * @param locale - UI language, forwarded to the platform for its messages.
   * @param force - bypass the cache (the panel's refresh button).
   */
  async snapshot(locale = 'zh-CN', force = false): Promise<BalanceSnapshot> {
    const now = this.now()
    if (!force && this.cached !== null && now - this.cached.at < this.cacheMs) return this.cached.snapshot
    if (this.inflight !== null) return this.inflight
    this.inflight = this.read(locale)
      .then((snapshot) => {
        // Only a successful read is worth caching; a transient platform
        // failure must not pin the panel to "failed" for a whole cache window.
        if (snapshot.state === 'ready') this.cached = { at: this.now(), snapshot }
        return snapshot
      })
      .finally(() => {
        this.inflight = null
      })
    return this.inflight
  }

  /** Drop the cache (tests, sign-in changes). */
  invalidate(): void {
    this.cached = null
  }

  private account(): UsageAccountService | undefined {
    return this.ctx.get('deepseekAccount') as UsageAccountService | undefined
  }

  private async read(locale: string): Promise<BalanceSnapshot> {
    const fetchedAt = this.now()
    const account = this.account()
    if (account === undefined) {
      return {
        state: 'unavailable',
        source: 'none',
        wallets: [],
        fetchedAt,
        error: 'account provider is not mounted on this host',
      }
    }
    const client: UsageAccountClient = {
      version: this.clientVersion,
      locale,
      timezoneOffsetSeconds: -new Date().getTimezoneOffset() * 60,
    }
    let result
    try {
      result = await account.getBalance(client)
    } catch (error) {
      return {
        state: 'failed',
        source: 'none',
        wallets: [],
        fetchedAt,
        error: error instanceof Error ? error.message : String(error),
      }
    }
    if (result === null || result === undefined) {
      return { state: 'signed-out', source: 'account', wallets: [], fetchedAt }
    }
    if (result.status !== 'ready') {
      return {
        state: 'failed',
        source: 'account',
        wallets: [],
        fetchedAt,
        error: 'the platform wallet query failed',
      }
    }
    const wallets: BalanceWallet[] = []
    for (const wallet of result.value ?? []) {
      const normalized = walletOf(wallet, 'recharge')
      if (normalized !== null) wallets.push(normalized)
    }
    for (const wallet of result.bonusWallets ?? []) {
      const normalized = walletOf(wallet, 'bonus')
      if (normalized !== null) wallets.push(normalized)
    }
    return { state: 'ready', source: 'account', wallets, fetchedAt }
  }
}
