/**
 * Range aggregation engine — a TS translation of the reasonix stats query
 * (internal/stats/query.go). It folds raw usage records (per call + per turn)
 * into the RangeStats the panel renders: per-day totals broken down by model
 * and provider, range totals, derived active days / cache hit-rate / top
 * model, and the per-model / per-provider ranked splits.
 *
 * The cache hit-rate is derived only from the input side (cacheHit +
 * cacheMiss), while the headline token total is PROVIDER-INCLUSIVE —
 * uncached input + output + cache reads + cache writes. That is the number
 * a provider dashboard reports for the same calls (and reasonix's
 * TotalTokens): DSH's TokenUsage splits DeepSeek's prompt_tokens into
 * disjoint input/cacheRead buckets, so the naive input+output sum would
 * hide the (typically dominant) cached share. The two rate denominators
 * never mix with the total.
 */

import type {
  ModelTokenUsage,
  ProviderTokenUsage,
  UsageStatsRange,
} from './wire.ts'
import { costOfBuckets, effectivePrice, peakShareOfDay, priceOf, roundMoney } from './pricing.ts'
import type { PriceBook } from './pricing.ts'

// Pure date/model-ref helpers live in the shared (host+client, zero-dep)
// module; imported for local use AND re-exported so the host-side import
// surface is unchanged.
import { dayKey, daysInRange, providerOf } from './shared.ts'
export { dayKey, daysInRange, providerOf }

/**
 * One atomic usage sample from a completed model call (or one completed
 * turn). A call sample carries the four token buckets and the model ref; a
 * turn marker carries only the day (the panel's "sessions" metric is one
 * completed turn). The request marker is ORTHOGONAL to the buckets: it counts
 * one provider call, and it rides alone on a call that reported no tokens
 * (`step/start`, a started retry) or alongside the buckets when the call
 * reports its own usage (`compaction/summary` — a call no `step/start`
 * opened).
 */
export interface UsageSample {
  day: string // local calendar day the call completed
  model?: string // canonical "provider/model"
  inputTokens: number
  outputTokens: number
  cacheReadTokens: number
  cacheWriteTokens: number
  turn?: boolean // true for a completed-turn marker
  request?: boolean // true when this sample also counts one provider call
}

export interface RangeFilter {
  from: string // inclusive day key
  to: string // inclusive day key
}

/** Aggregate the samples intersecting [from, to]. Missing days yield zero
 *  entries so the trend chart shows the full timeline.
 *
 *  With a `book`, every token-bearing sample is also costed: the four buckets
 *  are priced against the model's rate, scaled by the day's peak-hour share,
 *  and accumulated per range, per day and per model. Unpriced models keep
 *  their tokens but contribute no money — they are listed in
 *  `unpricedModels` so the panel can say so instead of showing a total that
 *  silently omits them. */
export function aggregateSamples(samples: Iterable<UsageSample>, filter: RangeFilter, book?: PriceBook): UsageStatsRange {
  const from = filter.from
  const to = filter.to
  const days = daysInRange(from, to)
  const out: UsageStatsRange = {
    from,
    to,
    tokens: 0,
    requests: 0,
    turns: 0,
    cacheHit: 0,
    cacheMiss: 0,
    activeDays: 0,
    topModel: '',
    topProvider: '',
    daily: [],
    models: [],
    providers: [],
    buckets: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
  }
  const modelTotals = new Map<string, number>()
  const providerTotals = new Map<string, number>()
  const active = new Set<string>()
  // Cost accumulators (only filled when a price book is supplied).
  const modelCosts = new Map<string, number>()
  const providerCosts = new Map<string, number>()
  const dayCostEst = new Map<string, number>()
  const dayCostMin = new Map<string, number>()
  const dayCostMax = new Map<string, number>()
  const unpriced = new Set<string>()
  let costEst = 0
  let costMin = 0
  let costMax = 0
  // Per-day accumulation (the reasonix dayTotals): the stacked trend chart
  // reads daily.byModel / daily.byProvider, so every token-bearing sample
  // must land in its day's map — not just in the range totals.
  const dayByModel = new Map<string, Map<string, number>>()
  const dayTotals = new Map<string, number>()
  const dayRequests = new Map<string, number>()
  const dayTurns = new Map<string, number>()
  const dayCacheHit = new Map<string, number>()
  const dayCacheMiss = new Map<string, number>()

  for (const sample of samples) {
    if (sample.day < from || sample.day > to) continue
    if (sample.turn) {
      out.turns++
      dayTurns.set(sample.day, (dayTurns.get(sample.day) ?? 0) + 1)
      continue
    }
    // Provider-inclusive headline (dashboard parity): every bucket the
    // provider billed for this call — uncached input, output, cache reads
    // and writes. The hit/miss rate denominators below stay input-side only.
    const total = sample.inputTokens + sample.outputTokens + sample.cacheReadTokens + sample.cacheWriteTokens
    if (sample.request) {
      // One provider call, whether or not it produced tokens — reasonix counts
      // failed calls too. A marker with no buckets is a request and nothing
      // else: it must not create a model row, mark its day active, or open an
      // empty daily bucket. A marker that DOES carry buckets
      // (`compaction/summary` states the call and its usage in one sample) is
      // counted here and again through the token accounting below — the two
      // count different things, so neither doubles the other.
      out.requests++
      dayRequests.set(sample.day, (dayRequests.get(sample.day) ?? 0) + 1)
      if (total <= 0) continue
    }
    out.tokens += total
    out.cacheHit += sample.cacheReadTokens
    // The miss side is everything prompt-side that was NOT a cache read:
    // uncached input plus cache writes. (This matches the official stats
    // line's billedInputTokens split — cacheHit/(cacheHit+cacheMiss) is the
    // same ratio on both surfaces; for DeepSeek cacheWrite is always 0.) */
    out.cacheMiss += sample.inputTokens + sample.cacheWriteTokens
    const buckets = out.buckets!
    buckets.input += sample.inputTokens
    buckets.output += sample.outputTokens
    buckets.cacheRead += sample.cacheReadTokens
    buckets.cacheWrite += sample.cacheWriteTokens
    const model = sample.model && sample.model !== '' ? sample.model : '(unknown)'
    modelTotals.set(model, (modelTotals.get(model) ?? 0) + total)
    providerTotals.set(providerOf(model), (providerTotals.get(providerOf(model)) ?? 0) + total)
    active.add(sample.day)

    // Money: price this sample's own buckets at its model's rate, scaled by
    // the peak-hour share of the day it landed on. The min/max bounds bill the
    // same tokens wholly off-peak / wholly at peak, so the panel can show the
    // spread the day-level store cannot resolve.
    if (book) {
      const price = priceOf(book, model)
      if (price === undefined) {
        unpriced.add(model)
      } else {
        const own = { input: sample.inputTokens, output: sample.outputTokens, cacheRead: sample.cacheReadTokens, cacheWrite: sample.cacheWriteTokens }
        const share = peakShareOfDay(sample.day)
        const est = costOfBuckets(own, effectivePrice(book, price, share))
        const lo = costOfBuckets(own, effectivePrice(book, price, 0))
        const hi = costOfBuckets(own, effectivePrice(book, price, 1))
        costEst += est
        costMin += lo
        costMax += hi
        modelCosts.set(model, (modelCosts.get(model) ?? 0) + est)
        const provider = providerOf(model)
        providerCosts.set(provider, (providerCosts.get(provider) ?? 0) + est)
        dayCostEst.set(sample.day, (dayCostEst.get(sample.day) ?? 0) + est)
        dayCostMin.set(sample.day, (dayCostMin.get(sample.day) ?? 0) + lo)
        dayCostMax.set(sample.day, (dayCostMax.get(sample.day) ?? 0) + hi)
      }
    }

    let byModel = dayByModel.get(sample.day)
    if (!byModel) {
      byModel = new Map()
      dayByModel.set(sample.day, byModel)
    }
    byModel.set(model, (byModel.get(model) ?? 0) + total)
    dayTotals.set(sample.day, (dayTotals.get(sample.day) ?? 0) + total)
    dayCacheHit.set(sample.day, (dayCacheHit.get(sample.day) ?? 0) + sample.cacheReadTokens)
    dayCacheMiss.set(sample.day, (dayCacheMiss.get(sample.day) ?? 0) + sample.inputTokens + sample.cacheWriteTokens)
  }

  out.activeDays = active.size

  // Daily series: emit every day of the range; inactive days carry zero totals.
  for (const day of days) {
    const byModel = dayByModel.get(day)
    const byModelObj: Record<string, number> = {}
    if (byModel) {
      for (const [m, v] of byModel) byModelObj[m] = v
    }
    const byProviderObj: Record<string, number> = {}
    for (const m of Object.keys(byModelObj)) {
      byProviderObj[providerOf(m)] = (byProviderObj[providerOf(m)] ?? 0) + byModelObj[m]!
    }
    out.daily.push({
      day,
      total: dayTotals.get(day) ?? 0,
      byModel: byModelObj,
      byProvider: byProviderObj,
      requests: dayRequests.get(day) ?? 0,
      turns: dayTurns.get(day) ?? 0,
      cacheHit: dayCacheHit.get(day) ?? 0,
      cacheMiss: dayCacheMiss.get(day) ?? 0,
      ...(book ? { cost: roundMoney(dayCostEst.get(day) ?? 0) } : {}),
    })
  }

  out.models = modelsSorted(modelTotals, modelCosts, unpriced)
  out.providers = providersSorted(providerTotals, providerCosts)
  if (book) {
    out.cost = {
      currency: book.currency,
      estimate: roundMoney(costEst),
      min: roundMoney(costMin),
      max: roundMoney(costMax),
    }
    out.pricing = book
    out.unpricedModels = [...unpriced].sort()
  }
  const top = out.models[0]
  if (top) {
    out.topModel = top.model
    out.topProvider = top.provider
  }
  if (out.tokens > 0) {
    for (const m of out.models) m.percent = (m.tokens / out.tokens) * 100
    for (const p of out.providers) p.percent = (p.tokens / out.tokens) * 100
  }
  return out
}

function modelsSorted(totals: Map<string, number>, costs: Map<string, number>, unpriced: Set<string>): ModelTokenUsage[] {
  const out: ModelTokenUsage[] = []
  for (const [model, tokens] of totals) {
    out.push({
      model,
      provider: providerOf(model),
      tokens,
      percent: 0,
      cost: roundMoney(costs.get(model) ?? 0),
      priced: !unpriced.has(model),
    })
  }
  out.sort((a, b) => b.tokens - a.tokens)
  return out
}

function providersSorted(totals: Map<string, number>, costs: Map<string, number>): ProviderTokenUsage[] {
  const out: ProviderTokenUsage[] = []
  for (const [provider, tokens] of totals) {
    out.push({ provider, tokens, percent: 0, cost: roundMoney(costs.get(provider) ?? 0) })
  }
  out.sort((a, b) => b.tokens - a.tokens)
  return out
}
