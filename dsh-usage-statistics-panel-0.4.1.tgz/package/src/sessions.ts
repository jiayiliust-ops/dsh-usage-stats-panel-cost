/**
 * Per-session usage: "how much did each conversation cost".
 *
 * The durable store aggregates by day × model, which cannot answer that — the
 * session identity is gone by the time a row is written. The only exact
 * source is each session's own event log, so this scanner replays the newest
 * N logs (newest first, capped) through a per-session fold: the same
 * (turn, step) dedupe the collector uses, the same route attribution
 * (`request/context` then the message's own `source`), and the same
 * `session/title` events for a human-readable name.
 *
 * The scan is expensive (one zstd decode per session), so its result is
 * cached for ten minutes and a caller can ask for a forced rescan. A failed
 * session is skipped, never fatal.
 */

import type {
  Context,
  UsageSessionEvent,
  UsageSessionHandleReader,
  UsageSessionHeader,
  UsageSessionInspection,
  UsageSessionPersistence,
  UsageSessionSnapshot,
} from './context-types.ts'
import type { PriceBook } from './pricing.ts'
import { costOfBuckets, effectivePrice, peakShareOfDay, priceOf, roundMoney } from './pricing.ts'
import { dayKey } from './shared.ts'
import type { SessionUsageList, SessionUsageRow } from './wire.ts'

/** The longest log this scanner will replay, as a guard against a runaway
 *  session file (the fold is linear, but memory is not). */
const MAX_EVENTS_PER_SESSION = 200_000

/** Read page size for the alpha handle seam. */
const READ_PAGE = 500

interface SessionSample {
  day: string
  input: number
  output: number
  cacheRead: number
  cacheWrite: number
  model: string
}

/** Normalize the two list shapes (rc.1 header rows, alpha snapshots). */
function headerOf(item: UsageSessionHeader | UsageSessionSnapshot): UsageSessionHeader | null {
  const snapshot = item as { header?: { id?: unknown } }
  if (snapshot !== null && typeof snapshot === 'object' && 'header' in snapshot) {
    const header = snapshot.header
    if (header !== null && typeof header === 'object' && typeof header.id === 'string') return header as UsageSessionHeader
  }
  const header = item as UsageSessionHeader
  return typeof header?.id === 'string' && header.id !== '' ? header : null
}

/** Read one session's whole event log through whichever seam the host offers
 *  (the alpha handle seam wins; rc.1 `inspect` is the fallback). */
async function readSessionEvents(
  persistence: UsageSessionPersistence,
  header: UsageSessionHeader,
  signal?: AbortSignal,
): Promise<{ events: readonly UsageSessionEvent[]; inheritedCut: number }> {
  if (typeof persistence.open === 'function') {
    const handle: UsageSessionHandleReader = await persistence.open(header.id, 'read', signal === undefined ? undefined : { signal })
    try {
      const cut = handle.inheritedEventCount
      const inheritedCut = typeof cut === 'number' && Number.isSafeInteger(cut) && cut >= 0 ? cut : 0
      const events: UsageSessionEvent[] = []
      let offset = 0
      for (;;) {
        if (events.length >= MAX_EVENTS_PER_SESSION) break
        const slice = await handle.read(offset, READ_PAGE, signal === undefined ? undefined : { signal })
        const page = (slice?.events ?? []) as readonly UsageSessionEvent[]
        if (page.length === 0) break
        for (const event of page) events.push(event)
        offset += page.length
      }
      return { events, inheritedCut }
    } finally {
      await handle.close().catch(() => {})
    }
  }
  if (typeof persistence.inspect === 'function') {
    const inspection: UsageSessionInspection = await persistence.inspect(header.id, signal)
    return { events: inspection.events, inheritedCut: inspection.inheritedEventCount ?? 0 }
  }
  throw new Error('no readable persistence seam (need open or inspect)')
}

/** Fold one session's events into its token buckets, cost, requests, turns
 *  and title. Unknown event types are ignored. */
function foldSession(
  events: readonly UsageSessionEvent[],
  inheritedCut: number,
): { title: string; lastActiveAt: number; samples: SessionSample[]; requests: number; turns: number } {
  const seen = new Map<string, SessionSample>()
  const loose: SessionSample[] = []
  let title = ''
  let lastActiveAt = 0
  let requests = 0
  let turns = 0
  let route = ''

  const sampleOf = (time: number, usage: { inputTokens?: number; outputTokens?: number; cacheReadTokens?: number; cacheWriteTokens?: number }, model: string): SessionSample => ({
    day: dayKey(time),
    input: usage.inputTokens ?? 0,
    output: usage.outputTokens ?? 0,
    cacheRead: usage.cacheReadTokens ?? 0,
    cacheWrite: usage.cacheWriteTokens ?? 0,
    model: model || route || '(unknown)',
  })

  const wants = (usage: { inputTokens?: number; outputTokens?: number; cacheReadTokens?: number; cacheWriteTokens?: number } | undefined): boolean => {
    if (usage === undefined) return false
    return (usage.inputTokens ?? 0) + (usage.outputTokens ?? 0) + (usage.cacheReadTokens ?? 0) + (usage.cacheWriteTokens ?? 0) > 0
  }

  for (const event of events) {
    if (typeof event.time === 'number' && event.time > lastActiveAt) lastActiveAt = event.time
    // Fork-inherited events belong to the parent session, whose own row
    // already counts them (the collector's backfill applies the same cut).
    if (inheritedCut > 0 && typeof event.seq === 'number' && event.seq < inheritedCut) continue
    const data = (event.data ?? {}) as Record<string, unknown>
    switch (event.type) {
      case 'session/title': {
        if (typeof data.title === 'string' && data.title !== '') title = data.title
        break
      }
      case 'request/context': {
        const provider = typeof data.provider === 'string' ? data.provider : ''
        const model = typeof data.model === 'string' ? data.model : ''
        if (provider !== '' && model !== '') route = `${provider}/${model}`
        else if (model !== '') route = model
        break
      }
      case 'step/start':
      case 'llm/retry-started': {
        requests += 1
        break
      }
      case 'turn/end': {
        turns += 1
        break
      }
      case 'assistant/message': {
        const usage = data.usage as Parameters<typeof wants>[0]
        if (!wants(usage)) break
        const message = data.message as { source?: { provider?: string; model?: string } } | undefined
        const source = message?.source
        const model = source?.provider !== undefined && source?.model !== undefined ? `${source.provider}/${source.model}` : (source?.model ?? route)
        const sample = sampleOf(event.time, usage!, model)
        const turn = data.turn
        const step = data.step
        if (typeof turn === 'number' && typeof step === 'number') seen.set(`${turn}:${step}`, sample)
        else loose.push(sample)
        break
      }
      case 'assistant/chunk': {
        // DSH <= 0.1.2 streaming sample: same (turn, step) slot as the final
        // message, so the later report replaces this one.
        const chunk = data.chunk as { type?: string; usage?: Parameters<typeof wants>[0] } | undefined
        if (chunk?.type !== 'usage' || !wants(chunk.usage)) break
        const sample = sampleOf(event.time, chunk.usage!, route)
        const turn = data.turn
        const step = data.step
        if (typeof turn === 'number' && typeof step === 'number') seen.set(`${turn}:${step}`, sample)
        else loose.push(sample)
        break
      }
      case 'compaction/summary': {
        // A summarization call sits outside the agent loop: it has no
        // step/start of its own, so it counts one request itself.
        requests += 1
        const usage = data.usage as Parameters<typeof wants>[0]
        if (!wants(usage)) break
        const provider = typeof data.provider === 'string' ? data.provider : ''
        const model = typeof data.model === 'string' ? data.model : ''
        const ref = provider !== '' && model !== '' ? `${provider}/${model}` : (model || route)
        const id = typeof data.compactionId === 'string' ? data.compactionId : ''
        const sample = sampleOf(event.time, usage!, ref)
        if (id !== '') seen.set(`c:${id}`, sample)
        else loose.push(sample)
        break
      }
      default:
        break
    }
  }
  return { title, lastActiveAt, samples: [...seen.values(), ...loose], requests, turns }
}

export interface SessionScanOptions {
  /** How many sessions to read, newest first (default 80). */
  limit?: number
  /** Cache lifetime in ms (default 10 min). */
  cacheMs?: number
  /** Concurrent log reads (default 2 — each one decodes a file). */
  concurrency?: number
}

/** Cached per-session usage scanner over the host's session persistence. */
export class SessionUsageScanner {
  private rows: SessionUsageRow[] | null = null
  private scannedAt = 0
  private scanning = false
  /** The scan every concurrent caller awaits, so opening the panel twice
   *  replays the logs once. */
  private inflight: Promise<void> | null = null
  private readonly limit: number
  private readonly cacheMs: number
  private readonly concurrency: number

  constructor(
    private readonly ctx: Context,
    private readonly book: () => PriceBook,
    options: SessionScanOptions = {},
  ) {
    this.limit = options.limit ?? 80
    this.cacheMs = options.cacheMs ?? 600_000
    this.concurrency = Math.max(1, options.concurrency ?? 2)
  }

  /** The current table: cached rows when fresh, otherwise a fresh scan. A
   *  concurrent caller shares the in-flight scan instead of starting another. */
  async list(force = false): Promise<SessionUsageList> {
    const fresh = this.rows !== null && !force && Date.now() - this.scannedAt < this.cacheMs
    if (fresh) return { rows: this.rows!, scannedAt: this.scannedAt, scanning: this.scanning, pending: 0 }
    if (this.inflight === null) {
      this.inflight = this.scan().finally(() => {
        this.inflight = null
      })
    }
    await this.inflight
    return { rows: this.rows ?? [], scannedAt: this.scannedAt, scanning: this.scanning, pending: 0 }
  }

  /** Drop the cache so the next read rescans. */
  invalidate(): void {
    this.rows = null
    this.scannedAt = 0
  }

  private async scan(): Promise<void> {
    const persistence = this.ctx.get('sessionPersistence') as UsageSessionPersistence | undefined
    if (persistence === undefined) {
      this.rows = []
      this.scannedAt = Date.now()
      return
    }
    this.scanning = true
    try {
      const raw = await persistence.list()
      const headers = raw
        .map(headerOf)
        .filter((h): h is UsageSessionHeader => h !== null)
        .sort((a, b) => (b.createdAt ?? 0) - (a.createdAt ?? 0))
        .slice(0, this.limit)
      const book = this.book()
      const rows: SessionUsageRow[] = new Array(headers.length)
      let next = 0
      const worker = async (): Promise<void> => {
        for (;;) {
          const index = next++
          if (index >= headers.length) return
          const header = headers[index]!
          try {
            const { events, inheritedCut } = await readSessionEvents(persistence, header)
            const folded = foldSession(events, inheritedCut)
            const buckets = { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 }
            // The same sample stream feeds three cuts of the same money: the
            // session total, the model split and the day split. The client
            // answers "which conversation spent this" from the day cut and
            // "what did this model cost" from the model cut.
            const byModelMoney = new Map<string, { tokens: number; cost: number }>()
            const byDayMoney = new Map<string, { tokens: number; cost: number }>()
            let tokens = 0
            let cost = 0
            for (const sample of folded.samples) {
              const own = { input: sample.input, output: sample.output, cacheRead: sample.cacheRead, cacheWrite: sample.cacheWrite }
              const sampleTokens = own.input + own.output + own.cacheRead + own.cacheWrite
              const price = priceOf(book, sample.model)
              const sampleCost = price === undefined
                ? 0
                : costOfBuckets(own, effectivePrice(book, price, peakShareOfDay(sample.day)))
              tokens += sampleTokens
              cost += sampleCost
              buckets.input += own.input
              buckets.output += own.output
              buckets.cacheRead += own.cacheRead
              buckets.cacheWrite += own.cacheWrite
              const modelSlice = byModelMoney.get(sample.model) ?? { tokens: 0, cost: 0 }
              modelSlice.tokens += sampleTokens
              modelSlice.cost += sampleCost
              byModelMoney.set(sample.model, modelSlice)
              const daySlice = byDayMoney.get(sample.day) ?? { tokens: 0, cost: 0 }
              daySlice.tokens += sampleTokens
              daySlice.cost += sampleCost
              byDayMoney.set(sample.day, daySlice)
            }
            const modelSplits = [...byModelMoney.entries()]
              .map(([model, slice]) => ({ model, tokens: slice.tokens, cost: roundMoney(slice.cost) }))
              .sort((a, b) => b.cost - a.cost || b.tokens - a.tokens)
            const daySplits = [...byDayMoney.entries()]
              .map(([day, slice]) => ({ day, tokens: slice.tokens, cost: roundMoney(slice.cost) }))
              .sort((a, b) => (a.day < b.day ? 1 : a.day > b.day ? -1 : 0))
            rows[index] = {
              id: header.id,
              title: folded.title,
              createdAt: header.createdAt ?? 0,
              lastActiveAt: folded.lastActiveAt || header.createdAt || 0,
              tokens,
              cost: roundMoney(cost),
              requests: folded.requests,
              turns: folded.turns,
              models: modelSplits.slice(0, 3).map((slice) => slice.model),
              byModel: modelSplits,
              byDay: daySplits,
            }
          } catch {
            // A single unreadable log must not fail the table.
            rows[index] = {
              id: header.id,
              title: '',
              createdAt: header.createdAt ?? 0,
              lastActiveAt: header.createdAt ?? 0,
              tokens: 0,
              cost: 0,
              requests: 0,
              turns: 0,
              models: [],
            }
          }
        }
      }
      await Promise.all(Array.from({ length: Math.min(this.concurrency, headers.length) }, () => worker()))
      this.rows = rows.filter((row) => row !== undefined && (row.tokens > 0 || row.requests > 0)).sort((a, b) => b.tokens - a.tokens)
      this.scannedAt = Date.now()
    } finally {
      this.scanning = false
    }
  }
}
