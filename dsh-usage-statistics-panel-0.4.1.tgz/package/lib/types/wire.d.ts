/**
 * Wire contract shared by the host aggregation layer and the browser panel,
 * plus the JSON request/response helpers for the /usage/api route handlers.
 * These types mirror the reasonix stats wire (internal/stats/query.go +
 * desktop/stats_app.go): the aggregate response the panel renders maps 1:1
 * to the panel sections (totals, derived stats, daily trend, per-model
 * split). No Node or DOM types leak into the shared declarations — the HTTP
 * helpers are host-only and import the node faces explicitly.
 */
import type { UsageHttpRequest, UsageHttpResponse } from './context-types.ts';
import type { Currency, PriceBook } from './pricing.ts';
/** The four disjoint token counters one range billed, before any pricing. */
export interface TokenBuckets {
    input: number;
    output: number;
    cacheRead: number;
    cacheWrite: number;
}
/**
 * The money a range cost, in three readings of the same usage.
 *
 * `estimate` weights each day by that day's peak-hour fraction; `min` bills
 * every token off-peak and `max` bills all of it at the peak rate. The store
 * has no hour granularity, so the estimate is the honest single number and
 * the bounds say how much the true bill can move.
 */
export interface CostSummary {
    currency: Currency;
    estimate: number;
    min: number;
    max: number;
}
/** One day's token usage and turn count in a trend series. */
export interface DailyTokenUsage {
    day: string;
    total: number;
    byModel: Record<string, number>;
    byProvider: Record<string, number>;
    requests: number;
    turns: number;
    cacheHit: number;
    cacheMiss: number;
    cost?: number;
}
/** One model's aggregate within the range. */
export interface ModelTokenUsage {
    model: string;
    provider: string;
    tokens: number;
    percent: number;
    cost?: number;
    priced?: boolean;
}
/** One provider's aggregate within the range (each provider may serve several models). */
export interface ProviderTokenUsage {
    provider: string;
    tokens: number;
    percent: number;
    cost?: number;
}
/** The full aggregate the panel renders for one time range. */
export interface UsageStatsRange {
    from: string;
    to: string;
    tokens: number;
    requests: number;
    turns: number;
    cacheHit: number;
    cacheMiss: number;
    activeDays: number;
    topModel: string;
    topProvider: string;
    daily: DailyTokenUsage[];
    models: ModelTokenUsage[];
    providers: ProviderTokenUsage[];
    buckets?: TokenBuckets;
    cost?: CostSummary;
    /** The price list this response was costed with (drives the price table). */
    pricing?: PriceBook;
    /** Model refs present in the range that the price list cannot price. */
    unpricedModels?: string[];
}
/** One wallet as the platform reports it: a recharge balance or a bonus. */
export interface BalanceWallet {
    currency: string;
    balance: number;
    kind: 'recharge' | 'bonus';
}
/** The account balance the panel shows above the cost sections. */
export interface BalanceSnapshot {
    state: 'ready' | 'signed-out' | 'unavailable' | 'failed';
    source: 'account' | 'none';
    wallets: BalanceWallet[];
    fetchedAt: number;
    /** Present when state is "failed" or "unavailable". */
    error?: string;
    /** Platform links for topping up / reading the official usage page. */
    links?: {
        topUpUrl?: string;
        usageUrl?: string;
    };
}
/** One fixed period in the overview strip. */
export interface PeriodUsage {
    key: 'today' | '7d' | '30d' | 'all';
    from: string;
    to: string;
    tokens: number;
    requests: number;
    cost: number;
}
/** Today / 7 days / 30 days / all time, costed in one currency. */
export interface UsageOverview {
    periods: PeriodUsage[];
    currency: Currency;
    generatedAt: number;
}
/** What one model cost inside one session. */
export interface SessionModelCost {
    model: string;
    tokens: number;
    cost: number;
}
/** What one calendar day cost inside one session. */
export interface SessionDayCost {
    day: string;
    tokens: number;
    cost: number;
}
/** One stored session's usage, from replaying its own log. */
export interface SessionUsageRow {
    id: string;
    title: string;
    createdAt: number;
    lastActiveAt: number;
    tokens: number;
    cost: number;
    requests: number;
    turns: number;
    /** Distinct model refs this session billed, most expensive first. */
    models: string[];
    /** Money split by model, most expensive first. */
    byModel?: SessionModelCost[];
    /** Money split by day, newest day first. */
    byDay?: SessionDayCost[];
}
/** The per-session usage table (每次使用的总量). */
export interface SessionUsageList {
    rows: SessionUsageRow[];
    scannedAt: number;
    scanning: boolean;
    /** Sessions the scan has not reached yet (rows are capped). */
    pending: number;
}
/** The usage statistics panel aggregate request. */
export interface UsageStatsRequest {
    range: string;
    from?: string;
    to?: string;
}
/** The backfill (historical session scan) progress state. */
export interface BackfillStatus {
    running: boolean;
    total: number;
    done: number;
    scannedSessions: number;
    lastSessionId?: string;
    error?: string;
}
/** One line of an async-iterable request body read as UTF-8 text. */
export declare function readJsonBody(req: UsageHttpRequest, maxBytes?: number): Promise<unknown>;
/** A user-visible error carrying its HTTP status. */
export declare class UsageError extends Error {
    readonly status: number;
    constructor(status: number, message: string);
}
export declare function writeJson(res: UsageHttpResponse, value: unknown, status?: number): void;
export declare function writeError(res: UsageHttpResponse, err: unknown): void;
