/**
 * Price book and cost math, shared by the host aggregation layer and the
 * browser panel.
 *
 * DeepSeek bills per 1M tokens on three channels — cached input, uncached
 * input, output — and doubles every channel during the Beijing-time peak
 * windows (09:00–12:00 and 14:00–18:00, Monday to Friday, excluding Chinese
 * statutory holidays). Off-peak is exactly half of peak, so the effective
 * price of one token is `offPeak × (1 + peakShare)`.
 *
 * The usage store aggregates by calendar DAY, not by hour, so a day's exact
 * peak/off-peak split is unknowable after the fact. The panel therefore
 * reports a weighted estimate (the day's peak-hour fraction) plus the
 * all-off-peak and all-peak bounds, and labels it as an estimate.
 *
 * This module MUST stay free of Node.js and DOM types and carry zero imports:
 * both halves import it at runtime, and the client bundle-purity gate rejects
 * Node builtins (the same rule src/shared.ts documents).
 */
/** Currencies the platform wallet and the public price list both use. */
export type Currency = 'CNY' | 'USD';
/** Display symbol for one currency. */
export declare const CURRENCY_SYMBOL: Record<Currency, string>;
/** Prices per 1,000,000 tokens at the OFF-PEAK rate. */
export interface ModelPrice {
    /** Cached input tokens (cache hit). */
    hit: number;
    /** Uncached input tokens (cache miss; cache writes bill here too). */
    miss: number;
    /** Output (completion) tokens. */
    output: number;
}
/** One currency's price list. */
export interface PriceBook {
    currency: Currency;
    /** Peak price ÷ off-peak price. DeepSeek's public list says peak = 2×. */
    peakMultiplier: number;
    /** Model family id -> its off-peak prices. */
    models: Record<string, ModelPrice>;
}
/** Per-1M prices already resolved for a peak share. */
export type ChannelPrice = ModelPrice;
/** The token buckets the panel bills: the four disjoint counters DSH reports. */
export interface BilledBuckets {
    input: number;
    output: number;
    cacheRead: number;
    cacheWrite: number;
}
/**
 * Official prices, per 1M tokens, off-peak, read from
 * https://api-docs.deepseek.com/quick_start/pricing (2026-10-31):
 *
 * | model            | cache hit | cache miss | output |
 * | ---------------- | --------- | ---------- | ------ |
 * | deepseek-flash   | ¥0.02     | ¥1         | ¥4     |
 * | deepseek-v4-pro  | ¥0.15     | ¥4.5       | ¥13.5  |
 *
 * USD list: flash 0.003 / 0.15 / 0.6; v4-pro 0.022 / 0.66 / 1.98.
 */
export declare const DEFAULT_PRICE_BOOKS: Record<Currency, PriceBook>;
/** Resolve a model ref to the price family that bills it, or null when the
 *  price list has no entry (the panel then reports the tokens as unpriced
 *  instead of silently applying another model's rate). */
export declare function priceFamilyOf(modelRef: string): string | null;
/** Off-peak prices for one model ref, or undefined when unpriced. */
export declare function priceOf(book: PriceBook, modelRef: string): ModelPrice | undefined;
/**
 * The peak windows, in Beijing wall-clock hours, Monday–Friday. DeepSeek
 * defines them in Beijing time; the panel's day keys are local calendar days,
 * which for a China-time machine is the same calendar. Defined as half-open
 * [start, end) hours.
 */
export declare const PEAK_WINDOWS: ReadonlyArray<{
    start: number;
    end: number;
}>;
/**
 * Fraction of one calendar day billed at the peak rate.
 *
 * Weekdays: 7/24. Weekends: 0. Chinese statutory holidays are NOT modelled —
 * the store keeps no holiday calendar, and treating them as peak days only
 * overstates cost by at most the day's peak/off-peak spread; the panel labels
 * the number as an estimate and shows the exact bounds beside it.
 *
 * @param day - local calendar day key, "YYYY-MM-DD".
 */
export declare function peakShareOfDay(day: string): number;
/** A price scaled to one peak share: `offPeak × (1 + share × (mult - 1))`. */
export declare function effectivePrice(book: PriceBook, price: ModelPrice, peakShare: number): ChannelPrice;
/**
 * Cost of one bucket set under already-scaled prices.
 *
 * Cache writes bill at the cache-miss rate (DeepSeek always reports 0 writes,
 * but a provider that does report them is charged on the prompt side).
 */
export declare function costOfBuckets(buckets: BilledBuckets, price: ChannelPrice): number;
/** Round a money value to the precision the wire carries (6 dp: sub-cent
 *  precision survives, float noise does not). */
export declare function roundMoney(value: number): number;
/** Format a money amount for display: two decimals above ¥1, up to four
 *  decimals below it so a small daily cost never reads as ¥0.00. */
export declare function formatMoney(value: number, currency: Currency): string;
/** Format a per-1M price for the price table: prices span ¥0.02 … ¥13.5, so
 *  the decimals follow the magnitude instead of a fixed precision. */
export declare function formatUnitPrice(value: number, currency: Currency): string;
