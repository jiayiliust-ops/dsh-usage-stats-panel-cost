/**
 * Typed fetch wrapper over the usage JSON API. Every call posts to
 * `usage/api/<method>` — DOCUMENT-RELATIVE, never root-absolute — with a JSON
 * body; the host resolves the range and returns the aggregate (or the backfill
 * status). Failures surface as {@link UsageApiError} with the wire code.
 *
 * Relative is the dsh 0.1.7 contract: the served index carries `<base
 * href="./">` (packages/host/frontend-static), so browser references resolve
 * under whatever mount served the page. A root-absolute `/usage/api/...` only
 * works when the shell sits at the origin root and 404s behind a
 * prefix-stripping proxy; the host's own route key stays absolute
 * (`/usage/api` in src/routes.ts), because only the browser half is relative.
 */
import type { BackfillStatus, BalanceSnapshot, SessionUsageList, UsageOverview, UsageStatsRange, UsageStatsRequest } from '../wire.ts';
/** One wire failure. */
export declare class UsageApiError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
/** Aggregate the usage panel renders for one range. */
export declare function fetchRange(req: UsageStatsRequest): Promise<UsageStatsRange>;
/** Rebuild the statistics from the session logs. The host wipes every row plus
 *  the backfill cursor and replays all persisted sessions under the current
 *  attribution rules, so a drifted store converges back onto the logs; it
 *  refuses (409) only while a boot scan is still running. */
export declare function rebuildStats(): Promise<BackfillStatus>;
/** Today / 7 days / 30 days / all time, already costed in one currency. */
export declare function fetchOverview(): Promise<UsageOverview>;
/**
 * Read the platform wallet balance.
 * @param locale - UI language, forwarded so the platform's own messages match.
 * @param force - bypass the host cache (the balance card's refresh button).
 */
export declare function fetchBalance(locale: string, force?: boolean): Promise<BalanceSnapshot>;
/**
 * Read the per-conversation usage table. The host caches it for ten minutes;
 * `force` asks for a replay of the newest session logs.
 */
export declare function fetchSessions(force?: boolean): Promise<SessionUsageList>;
