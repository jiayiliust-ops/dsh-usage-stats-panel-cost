/**
 * The /usage/api route table: a small JSON RPC over the fenced web route.
 * Methods:
 *   - range    { range, from?, to?, source? } -> UsageStatsRange
 *   - overview {} -> UsageOverview (today / 7d / 30d / all, costed)
 *   - balance  { locale?, force? } -> BalanceSnapshot (platform wallets)
 *   - sessions { force? } -> SessionUsageList (per-conversation totals)
 *   - status   {} -> BackfillStatus
 *   - reset    {} -> drop every row + cursor, then rescan all persisted
 *                sessions (the store-rebuild escape hatch)
 * The prefix route /usage/api is registered on the webserver; each request
 * passes the browser-trust fence (Host-header loopback, a trusted authority, or
 * this listener's own bind address).
 */
import type { Context } from './context-types.ts';
import type { UsageWebRoute } from './context-types.ts';
import type { BalanceService } from './balance.ts';
import type { SessionUsageScanner } from './sessions.ts';
import { UsageStore } from './store.ts';
import { UsageCollector } from './collector.ts';
import type { PriceBook } from './pricing.ts';
import type { BackfillStatus, UsageOverview, UsageStatsRange, UsageStatsRequest } from './wire.ts';
import { type TrustInputs } from './trust-fence.ts';
export interface RoutesDeps {
    store: UsageStore;
    collector: UsageCollector;
    /** Resolve the /usage/api trust inputs live: the trusted authorities, this
     *  listener's bind address, and its protocol (see trust-fence TrustInputs). */
    trust: () => TrustInputs;
    /** Whether a /reset rebuild pipeline is currently in flight (its scan
     *  makes the collector report running too — callers use this to tell that
     *  benign state apart from a boot scan and COALESCE onto the pipeline
     *  instead of refusing). */
    isRebuilding: () => boolean;
    /** Wipe the store at wipe-time live watermarks and re-run the full
     *  backfill (wired by the host half; concurrent calls coalesce into one
     *  rebuild). */
    resetAndRescan: () => Promise<void>;
    /** The price book to cost responses with. Async because the currency can
     *  follow the platform wallet (a USD account must not be billed at CNY
     *  rates); the host caches the wallet read, so this is cheap. */
    pricing: () => Promise<PriceBook>;
    /** Platform wallet reader (the panel's balance card). */
    balance: BalanceService;
    /** Per-session usage scanner (the panel's "each conversation" table). */
    sessions: SessionUsageScanner;
}
/** Resolve a request's [from, to] into inclusive local day keys. */
export declare function resolveRange(req: UsageStatsRequest, now?: Date): {
    from: string;
    to: string;
};
/** Build the aggregate for a range from the store rows. The per-row request
 *  and turn counts are yielded lazily as markers, so no intermediate array
 *  is materialized regardless of range size. When a price book is given, the
 *  aggregate also carries the range/day/model costs. */
export declare function aggregateRange(store: UsageStore, from: string, to: string, book?: PriceBook): Promise<UsageStatsRange>;
/** The overview strip: the same aggregate over today, the last 7 and 30 days,
 *  and everything the store has ever recorded. "All" starts at the earliest
 *  stored day, so a fresh install does not scan a year of empty calendar. */
export declare function aggregateOverview(store: UsageStore, book: PriceBook, now?: Date): Promise<UsageOverview>;
/** Build the single fenced prefix route serving the /usage/api JSON RPC.
 *  The host mounts it via `ctx.webServer.register` (which takes ONE WebRoute,
 *  not an array — matching the real dsh-host-webserver contract). */
export declare function buildUsageRoute(ctx: Context, deps: RoutesDeps): UsageWebRoute;
export type { BackfillStatus, UsageStatsRange, UsageStatsRequest };
