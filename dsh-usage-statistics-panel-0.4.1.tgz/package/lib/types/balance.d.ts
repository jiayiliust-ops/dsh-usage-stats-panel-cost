/**
 * Account balance: the "how much money is left" half of the cost view.
 *
 * DeepSeek Harness signs in to the DeepSeek **platform** account (provider
 * `deepseek-account`), so the balance is the platform wallet, not the pay-as-
 * you-go API key balance. The host already owns that authenticated query:
 * `deepseekAccount.getBalance(client)` reads `GET /api/v0/users/get_user_summary`
 * with the stored grant and returns the recharge and bonus wallets. This
 * module wraps that service with a short cache (the panel refreshes on demand
 * and on range switches) and normalizes it into the wire shape.
 *
 * Everything degrades instead of throwing: a signed-out account, a host
 * without the account provider, and a failed platform call all produce a
 * snapshot the panel can render as a one-line state, never a dead section.
 */
import type { Context } from './context-types.ts';
import type { BalanceSnapshot } from './wire.ts';
export interface BalanceOptions {
    /** How long a snapshot stays fresh (default 60 s). */
    cacheMs?: number;
    /** Host version forwarded to the platform as `x-client-version`. */
    clientVersion?: string;
    /** Extra client identity headers (locale is per request). */
    now?: () => number;
}
/** Cached, normalized balance reader over the host account service. */
export declare class BalanceService {
    private readonly ctx;
    private cached;
    private inflight;
    private readonly cacheMs;
    private readonly clientVersion;
    private readonly now;
    constructor(ctx: Context, options?: BalanceOptions);
    /** The platform links (top-up / official usage page), independent of the
     *  balance read so a failed query still sends the user somewhere useful. */
    links(): Promise<{
        topUpUrl?: string;
        usageUrl?: string;
    }>;
    /**
     * Read the current balance.
     * @param locale - UI language, forwarded to the platform for its messages.
     * @param force - bypass the cache (the panel's refresh button).
     */
    snapshot(locale?: string, force?: boolean): Promise<BalanceSnapshot>;
    /** Drop the cache (tests, sign-in changes). */
    invalidate(): void;
    private account;
    private read;
}
