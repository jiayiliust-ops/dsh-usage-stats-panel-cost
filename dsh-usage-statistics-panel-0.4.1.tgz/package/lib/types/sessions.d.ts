/**
 * Per-session usage: "how much did each conversation cost".
 *
 * The durable store aggregates by day × model, which cannot answer that — the
 * session identity is gone by the time a row is written. The only exact
 * source is each session's own event log, so this scanner replays the newest
 * N logs (newest first, capped) through a per-session fold: the same
 * (turn, step) dedupe the collector uses, the same route attribution
 * (`request/context` then the message's own `source`), and the same
 * `session/title` events for a human-readable name.
 *
 * The scan is expensive (one zstd decode per session), so its result is
 * cached for ten minutes and a caller can ask for a forced rescan. A failed
 * session is skipped, never fatal.
 */
import type { Context } from './context-types.ts';
import type { PriceBook } from './pricing.ts';
import type { SessionUsageList } from './wire.ts';
export interface SessionScanOptions {
    /** How many sessions to read, newest first (default 80). */
    limit?: number;
    /** Cache lifetime in ms (default 10 min). */
    cacheMs?: number;
    /** Concurrent log reads (default 2 — each one decodes a file). */
    concurrency?: number;
}
/** Cached per-session usage scanner over the host's session persistence. */
export declare class SessionUsageScanner {
    private readonly ctx;
    private readonly book;
    private rows;
    private scannedAt;
    private scanning;
    /** The scan every concurrent caller awaits, so opening the panel twice
     *  replays the logs once. */
    private inflight;
    private readonly limit;
    private readonly cacheMs;
    private readonly concurrency;
    constructor(ctx: Context, book: () => PriceBook, options?: SessionScanOptions);
    /** The current table: cached rows when fresh, otherwise a fresh scan. A
     *  concurrent caller shares the in-flight scan instead of starting another. */
    list(force?: boolean): Promise<SessionUsageList>;
    /** Drop the cache so the next read rescans. */
    invalidate(): void;
    private scan;
}
